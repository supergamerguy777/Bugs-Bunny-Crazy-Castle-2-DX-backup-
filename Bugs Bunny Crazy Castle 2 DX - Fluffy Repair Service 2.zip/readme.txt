Bugs Bunny Crazy Castle 2 DX - Fluffy Repair Service


Latest:
2021-12-03



//////////////////////////////////////////////////////////////////



Bugs Bunny Crazy Castle 2 DX  (FroggestSpirit):


0) Use original rom
   Bugs Bunny Crazy Castle 2, The (USA).gb



1) Apply patch 1.0
   https://www.romhacking.net/hacks/944/



2) Then dx_basic.ips



______________________________________________________________



Basic:


gbc_compatible

*  Fixes vram graphics corruption
   Fixes missing ending scene
   Fixes missing warp fade effect
   Fixes black flicker


_______________________________________________



Commits:

2 - gbc_compatible updated

    *  warp fade effect
    *  black flicker



1 - gbc_compatible released


_______________________________________________



Visit:

*  Source Code
   https://github.com/minucce-yard/Bugs_Bunny_Crazy_Castle_2_GB


*  Discuss
   https://www.romhacking.net/forum/index.php?topic=33527.0


_______________________________________________



Comments:

*  Cheats

   c380 = level  (00-1c)
   c3b8 = keys   (00-08)
   c3cd = arrow  (00-08)
